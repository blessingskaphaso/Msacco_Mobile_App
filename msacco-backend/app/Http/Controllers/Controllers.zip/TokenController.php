<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TokenController extends Controller
{
    public function index()
    {
        // Return all tokens
    }

    public function store(Request $request)
    {
        // Create a new token
    }

    public function destroy($id)
    {
        // Delete a token
    }
}
