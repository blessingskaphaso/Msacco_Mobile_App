<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class NotificationController extends Controller
{
    public function index()
    {
        // Return all notifications
    }

    public function store(Request $request)
    {
        // Create a new notification
    }

    public function show($id)
    {
        // Show specific notification
    }

    public function markAsRead($id)
    {
        // Mark a notification as read
    }
}
