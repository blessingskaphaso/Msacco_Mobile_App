<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RepaymentController extends Controller
{
    public function index()
    {
        // Return all repayments
    }

    public function store(Request $request)
    {
        // Create a new repayment
    }

    public function show($id)
    {
        // Show a specific repayment
    }

    public function destroy($id)
    {
        // Delete a repayment
    }
}
