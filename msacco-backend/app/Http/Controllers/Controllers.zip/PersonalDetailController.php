<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PersonalDetailController extends Controller
{
    public function index()
    {
        // Return all personal details
    }

    public function store(Request $request)
    {
        // Create new personal detail
    }

    public function show($id)
    {
        // Show specific personal detail
    }

    public function update(Request $request, $id)
    {
        // Update specific personal detail
    }
}
