<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DocumentController extends Controller
{
    public function index()
    {
        // Return all documents
    }

    public function store(Request $request)
    {
        // Upload a new document
    }

    public function show($id)
    {
        // Show specific document
    }

    public function destroy($id)
    {
        // Delete a document
    }
}
