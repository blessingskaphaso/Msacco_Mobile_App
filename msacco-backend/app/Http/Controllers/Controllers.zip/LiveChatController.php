<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LiveChatController extends Controller
{
    public function index()
    {
        // Return all live chat messages
    }

    public function store(Request $request)
    {
        // Send a new message
    }

    public function show($id)
    {
        // Show specific chat message
    }
}
