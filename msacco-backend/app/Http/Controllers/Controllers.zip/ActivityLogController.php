<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ActivityLogController extends Controller
{
    public function index()
    {
        // Return all activity logs
    }

    public function store(Request $request)
    {
        // Log a new activity
    }

    public function show($id)
    {
        // Show specific activity log
    }
}
